package Model.Products;

public class Dimensions {

}
