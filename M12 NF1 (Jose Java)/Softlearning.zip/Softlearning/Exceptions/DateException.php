<?php

class DateException extends Exception{
    //put your code here
}
