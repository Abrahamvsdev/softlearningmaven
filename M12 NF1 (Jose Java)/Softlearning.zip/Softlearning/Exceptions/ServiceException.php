<?php

declare(strict_types=1);

class ServiceException extends Exception{
    //put your code here
}
