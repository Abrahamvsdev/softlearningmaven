<?php

class BuildException extends Exception{
    //put your code here
}
