<?php


include($_SERVER['DOCUMENT_ROOT'] . '/softlearning/model/Products/Product.php');
include($_SERVER['DOCUMENT_ROOT'] . '/softlearning/model/stakeholders/Dimensions.php');
include($_SERVER['DOCUMENT_ROOT'] . '/softlearning/model/Products/Storable.php');
include($_SERVER['DOCUMENT_ROOT'] . '/softlearning/model/operations/Check.php');
include($_SERVER['DOCUMENT_ROOT'] . '/softlearning/Exceptions/DateException.php');
//include_once '../model/operations/Check.php';



//$date = (int)filter_input(INPUT_POST, "Date");


//if($date !=null){


    //print Check::checkDate($date);
   //var_dump($date);
//$date= "29/02/2018";

//$date = $_POST['date'];
//print Check::checkDate($date);
        

