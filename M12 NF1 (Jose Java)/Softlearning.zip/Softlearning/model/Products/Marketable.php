<?php

interface Marketable {
   public function hasDelayPay();
   public function getDiscount();
   public function getType();
   
}

