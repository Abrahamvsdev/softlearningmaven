<?php


interface Stakeholder {
    
    public function printMessageInterface(); 
    

    
}
